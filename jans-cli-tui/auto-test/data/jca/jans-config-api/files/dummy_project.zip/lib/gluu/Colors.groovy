package gluu

class Colors {
    
    static def map = [red: '#FF0000', green: '#00FF00', blue: '#0000FF']
       
    String rgbOf(String name) {
        map[name]
    }

}
