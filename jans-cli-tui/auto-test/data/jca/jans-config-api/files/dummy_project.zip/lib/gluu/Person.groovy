package gluu

import gluu.util.Fib

class Person {

    String name

    String greet(String otherPerson) {
       "Hello ${otherPerson}, I am ${name}"
    }
    
    int luckyNumber() {
        Fib.fib(name.length())
    }
    
    String favColor() {
        int maxColors = Colors.map.size()
        int index = name.length() % maxColors
        Colors.map.values()[index]
    }

}
