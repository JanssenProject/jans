package io.jans.agamalab.notify;

import io.jans.model.custom.script.model.CustomScript;
import io.jans.model.SimpleCustomProperty;
import io.jans.service.cdi.util.CdiUtil;
import io.jans.service.custom.CustomScriptService;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static java.nio.charset.StandardCharsets.UTF_8;

public class Configuration {

    private static final String CREDS_PROPERTY = "credentials_file";
    private static final String SERVICE_MODE_PROPERTY = "notification_service_mode";

    private static Configuration instance;
    
    private Logger logger = LoggerFactory.getLogger(getClass());
    
    private Path credsPath;
    private JSONObject configs;
    
    private long lastModifiedCreds = -1;
    
    private Configuration() {

        logger.info("Checking super_gluu custom script");
        CustomScript script = CdiUtil.bean(CustomScriptService.class).getScriptByDisplayName("super_gluu");
        
        List<SimpleCustomProperty> properties = script.getConfigurationProperties();
        
        logger.debug("Looking up service mode");
        String mode = properties.stream()
                    .filter(p -> SERVICE_MODE_PROPERTY.equals(p.getValue1())).findAny().get().getValue2();
        
        if (!mode.equals("jans"))
            throw new IOException("Service mode '" + mode + "' for super gluu notifications is not supported. Use 'jans'");
        
        logger.debug("Looking up credentials file path");
        String fn = properties.stream()
                    .filter(p -> CREDS_PROPERTY.equals(p.getValue1())).findAny().get().getValue2();
        logger.debug("File path is: {}", fn);
        
        credsPath = Paths.get(fn);

    }
    
    public static Configuration getInstance() {
        if (instance == null) {
            instance = new Configuration();
        }
        return instance;
    }
    
    public JSONObject get() {
        
        long lastModified = Files.getLastModifiedTime(credsPath).toMillis();
        if (lastModified > lastModifiedCreds) {
            lastModifiedCreds = lastModified;            
            configs = new JSONObject(Files.readString(credsPath, UTF_8));
        }
        return configs;
        
    }
    
}
