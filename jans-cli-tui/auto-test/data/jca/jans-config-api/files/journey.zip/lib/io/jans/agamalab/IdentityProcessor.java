package io.jans.agamalab;

import io.jans.as.common.model.common.User;
import io.jans.as.common.service.common.UserService;
import io.jans.as.model.exception.InvalidClaimException;
import io.jans.orm.exception.operation.EntryNotFoundException;
import io.jans.service.cdi.util.CdiUtil;
import io.jans.util.StringHelper;

import java.util.HashMap;
import java.util.Arrays;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static io.jans.inbound.Attrs.*;

public class IdentityProcessor {

    private static final Logger logger = LoggerFactory.getLogger(IdentityProcessor.class);

    private static final String INUM_ATTR = "inum";
    private static final String EXT_ATTR = "jansExtUid";
        
    public static Map<String, String> accountFromEmail(String email) {

        User user = getUser(MAIL, email);
        boolean local = user != null;
        logger.debug("There is {} local account for {}", local ? "a" : "no", email);
        
        if (local) {
            String uid = user.getUserId();//getSingleValuedAttr(user, UID);
            String inum = getSingleValuedAttr(user, INUM_ATTR);
            String name = getSingleValuedAttr(user, GIVEN_NAME);

            if (name == null) {
                name = getSingleValuedAttr(user, DISPLAY_NAME);
            }
            return Map.of(UID, uid, INUM_ATTR, inum, "name", name, MAIL, email);
        }
        return Collections.emptyMap();

    }

    public static Map<String, String> remoteAccountDetails(String extUid) {
        
        User user = getUser(EXT_ATTR, extUid);
        boolean remote = user != null;
        
        Map<String, String> details = null;
        logger.debug("There is {} local account mapping to the remote account {}", remote ? "a" : "no", extUid);
        
        if (remote) {
            details = new HashMap<>();            
            
            for (String attr : Arrays.asList(INUM_ATTR, UID, GIVEN_NAME)) {                
                String val = getSingleValuedAttr(user, attr);
                if (val != null) {
                    details.put(attr, val);
                }
            }
        }
        return details;

    }
    
    public static String externalIdOf(String provider, String id) {
        return provider + ":" + id;
    }
    
    public static String onboard(Map<String, String> profile, Set<String> attributes, String extUid)
        throws Exception {
        
        User user = new User();
        if (StringHelper.isEmpty(profile.get(GIVEN_NAME))) throw new Exception("First name not provided");

        if (extUid != null) {
            user.setAttribute(EXT_ATTR, extUid, true);
        }
        
        attributes.forEach(attr -> {
                String val = profile.get(attr);
                if (StringHelper.isNotEmpty(val)) {
                    user.setAttribute(attr, val);
                }
        });
        UserService userService = CdiUtil.bean(UserService.class);
        
        user = userService.addUser(user, true);
        if (user == null) throw new EntryNotFoundException("Added user not found");
        
        return getSingleValuedAttr(user, INUM_ATTR);
        
    }
    
    private static User getUser(String attributeName, String value) {
        UserService userService = CdiUtil.bean(UserService.class);
        return userService.getUserByAttribute(attributeName, value, true);
    }

    private static String getSingleValuedAttr(User user, String attribute) {
        return user.getAttribute(attribute, false, false).toString();
    }
    
}
